<?php

Route::resource('announcements', 'Announcement\Controllers\AnnouncementController');
