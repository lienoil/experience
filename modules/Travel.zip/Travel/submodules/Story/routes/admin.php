<?php

Route::resource('stories', 'Story\Controllers\StoryController');
