@extends("Theme::layouts.auth")
@section("head-title", __($application->page->title))
@section("page-title", __($application->page->title))

@section("content")
    <v-card class="elevation-1 sticky">
        <v-toolbar class="elevation-0 white">
            <a href="\home">
			    <img src="{{ assets('frontier/images/public/logo_icon.png') }}" alt="" width="80" style="padding-top: 8px;">
			</a>
			<v-spacer></v-spacer>
			<a href="">
				<v-avatar size="40px">
					<img src="{{ assets('frontier/images/placeholder/man.png') }}" alt="">
				</v-avatar>
			</a>
        </v-toolbar>
    </v-card>
    <v-toolbar dark extended class="blue elevation-0">
        <v-btn
            ripple
            href="\experiences/show"
            flat
            >
            <v-icon left dark>arrow_back</v-icon>
            Back
        </v-btn>
    </v-toolbar>
	<v-container fluid grid-list-lg>
        <v-layout row wrap align-top justify-center>
            <v-flex lg8 md10 sm10 xs12>
            	<v-layout row wrap align-top justify-center>
					<v-flex md8 xs12>
						<v-card class="elevation-1 card--flex-toolbar">
                            <v-toolbar class="transparent elevation-0">
                                <v-toolbar-title>Review Guest Requirements</v-toolbar-title>
                            </v-toolbar>
                            <v-divider></v-divider>

                            <v-card-text>
                                <div class="pt-3 subheading">
                                    <div><strong>Alcohol</strong></div>
                                    This experience includes alcohol. Only guests who meet the legal drinking age will be served alcoholic beverages.
                                </div>
                            </v-card-text>

                            <v-card-text>
                                <div class="pt-3 subheading">
                                    <div><strong>Who can come</strong></div>
                                	Guests ages 18 and up can attend.
                                </div>
                            </v-card-text>

                            <v-card-text>
                                <div class="pt-3 subheading">
                                    <div><strong>Who’s coming?</strong></div>
									<v-card-actions class="pt-0 pb-3">
										<v-avatar size="50px">
											<img src="{{ assets('frontier/images/placeholder/man.png') }}"/>
										</v-avatar>
                                        <div class="pl-3">Angelina Scott</div>
									</v-card-actions>
									<v-card-actions class="pt-0 pb-3">
                                        <v-spacer></v-spacer>
										<v-btn v-tooltip:bottom="{ html: 'Add another guest' }" class="green green--text" fab outline small>
                                            <v-icon>add</v-icon></v-btn
									</v-card-actions>
                                </div>
                            </v-card-text>

                            <v-divider class="hidden-sm-and-down"></v-divider>
                            <v-card-text class="text-xs-right hidden-sm-and-down">
    							<v-btn primary large class="elevation-1" href="\billings/show">Next</v-btn>
                            </v-card-text>
                        </v-card>
					</v-flex>

					<v-flex md4 xs12 class="hidden-sm-and-down">
                        <v-card class="elevation-1 mb-3 card--flex-toolbar">
                            <v-card-text class="py-4">
								<div class="title mb-2 fw-500">Random Road Trip #1</div>
								<div>Hosted by Paul Appleseed</div>
                            </v-card-text>
                            <v-divider></v-divider>
                            <v-card-text class="py-4">
								<div class="subheading">November 24 to 26, 2017</div>
								<div class="subheading">Starts at 8pm, Friday</div>
								<div class="subheading">3 days</div>
                            </v-card-text>
                            <v-divider></v-divider>
                            <v-card-text class="py-4">
								<v-card-actions class="pa-0">
									<div class="subheading">₱ 6,000 x 1 guest</div>
									<v-spacer></v-spacer>
									<div class="subheading">₱ 6,000</div>
								</v-card-actions>
                            </v-card-text>
                            <v-divider></v-divider>
                            <v-card-text class="py-4">
								<v-card-actions class="pa-0">
									<div class="subheading">Total (PHP)</div>
									<v-spacer></v-spacer>
									<div class="title"><strong>₱ 6,000</strong></div>
								</v-card-actions>
                            </v-card-text>
                        </v-card>
                        <v-card class="elevation-1 mb-3">
                            <v-card-text class="py-4">
                                <div class="subheading success--text mb-3">Cancellation Policy</div>
                                <div class="body-1 mb-2">Get a <strong>full refund</strong> if you cancel before 2 weeks ( more than 10 business days ) before the trip.</div>
                                <div class="body-1 mb-2"><strong>Half Refund</strong> within 10 business days but more than 5 days before the trip.</div>
                                <div class="body-1 mb-2"><strong>No Refund</strong> within 5 days or less before the trip</div>
                            </v-card-text>
                        </v-card>
					</v-flex>
            	</v-layout>
            </v-flex>
        </v-layout>
    </v-container>

    <v-card class="elevation-1 fixed-nav hidden-md-and-up" style="z-index: 3;">
        <v-layout row wrap>
            <v-flex xs12>
                <v-card-actions>
                    <v-card-text class="py-2">
                        <div class="subheading"><strong>₱ 6,000</strong> <span class="body-1">per person</span></div>
                        <v-dialog class="hidden-md-and-up" v-model="dialog.billing" fullscreen transition="dialog-bottom-transition" :overlay=false>
                        <v-btn flat small class="body-2 primary--text ml-0 details-btn" slot="activator">See details</v-btn>
			                <v-card>
			                    <v-toolbar light class="white elevation-0">
			                    	<v-spacer></v-spacer>
			                        <v-btn icon @click.native="dialog.billing = false">
			                            <v-icon>close</v-icon>
			                        </v-btn>
			                    </v-toolbar>
			                    <v-card-text class="py-4">
									<div class="title mb-2 fw-500">Random Road Trip #1</div>
									<div>Hosted by Paul Appleseed</div>
	                            </v-card-text>
	                            <v-divider></v-divider>
	                            <v-card-text class="py-4">
									<div class="subheading">November 24 to 26, 2017</div>
									<div class="subheading">Starts at 8pm, Friday</div>
									<div class="subheading">3 days</div>
	                            </v-card-text>
	                            <v-divider></v-divider>
	                            <v-card-text class="py-4">
									<v-card-actions class="pa-0">
										<div class="subheading">₱ 6,000 x 1 guest</div>
										<v-spacer></v-spacer>
										<div class="subheading">₱ 6,000</div>
									</v-card-actions>
	                            </v-card-text>
	                            <v-divider></v-divider>
	                            <v-card-text class="py-4">
									<v-card-actions class="pa-0">
										<div class="subheading">Total (PHP)</div>
										<v-spacer></v-spacer>
										<div class="title"><strong>₱ 6,000</strong></div>
									</v-card-actions>
                            	</v-card-text>
                                <v-divider></v-divider>
                                <v-card-text class="py-4">
                                    <div class="subheading success--text mb-3">Cancellation Policy</div>
                                    <div class="body-1 mb-3">Get a <strong>full refund</strong> if you cancel before 2 weeks <br> ( more than 10 business days ) before the trip.</div>
                                    <div class="body-1 mb-3"><strong>Half Refund</strong> within 10 business days but more than 5 days before the trip.</div>
                                    <div class="body-1 mb-3"><strong>No Refund</strong> within 5 days or less before the trip</div>
                                </v-card-text>
			                </v-card>
			            </v-dialog>
                    </v-card-text>
                    <v-spacer></v-spacer>
                    <v-card-text class="py-2 text-xs-right">
                        <v-btn large primary class="elevation-1 px-2" href="\billings\show">Next</v-btn>
                    </v-card-text>
                </v-card-actions>
            </v-flex>
        </v-layout>
    </v-card>
@endsection

@push('css')
    <style>
    	.fw-400 {
            font-weight: 400;
        }
        .fw-500 {
            font-weight: 500;
        }
        .fixed-nav {
            position: fixed !important;
            bottom: 0;
            width: 100%;
            z-index: 1;
        }
        .details-btn .btn__content {
        	padding-left: 0;
        	padding-right: 0;
        }
        .card--flex-toolbar {
            margin-top: -80px;
        }
    </style>
@endpush

@push('pre-scripts')
    <script src="{{ assets('frontier/vendors/vue/resource/vue-resource.min.js') }}"></script>
    <script>
        Vue.use(VueResource);

        mixins.push({
            data () {
                return {
                	dialog: {
                        billing: false
                    },
                }
            },
        });
    </script>
@endpush
