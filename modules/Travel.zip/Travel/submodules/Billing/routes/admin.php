<?php

Route::resource('billings', 'Billing\Controllers\BillingController');
