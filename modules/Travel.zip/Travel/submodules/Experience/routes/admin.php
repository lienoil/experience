<?php

Route::resource('experiences', 'Experience\Controllers\ExperienceController');
