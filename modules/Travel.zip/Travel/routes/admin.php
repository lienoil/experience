<?php

Route::resource('travels', 'Travel\Controllers\TravelController');
