<div class="" style=" background-image: url(http://experience/assets/frontier/images/placeholder/b-reverse.png); background-repeat: repeat-x; width: 100%; height: 100px; margin-bottom: 20px;"></div>
